package com.example.demo;


	

	import org.junit.Test;
	import org.junit.runner.RunWith;
	import org.springframework.beans.factory.annotation.Autowired;

	import com.example.demo.model.User;
	import com.example.demo.repository.UserRepository;
	import com.mongodb.DBCollection;
	import com.mongodb.MongoClient;

	import java.util.List;
	import static org.junit.Assert.assertEquals;
	import static org.junit.Assert.assertTrue;

	public class UserServicetest {

		
		@Test
		public void testfindByPhone()
		{
			
			UserService1 repository=new UserService1();
	String phone="9035117623";
		assertEquals(phone,repository.findByPhone("9035117623"));
		}
		@Test
		public void testfindByName()
		{
			UserService1 repository=new UserService1();
			String email="yashu";
		assertEquals(email,repository.findByName("yashu"));
		}

		@Test
		public void testfindByEmail()
		{
			UserService1 repository=new UserService1();
			String email="bindu@cap.com";
			
		assertEquals(email,repository.findByEmail("bindu@cap.com"));
		}
		 
		
		@Test
		public void testfindByNameAndPassword(){
		
			
			UserService1 repository=new UserService1();
	String actual=repository.findByNameAndPassword("Bindu", "bindu@bu1");

		assertTrue("bindu@bu1".equals(actual) || "Bindu".equals(actual));
		
		}
		 
		
		@Test
		public void testfindByEmailAndPassword(){
		
			
			UserService1 repository=new UserService1();
			String actual=repository.findByEmailAndPassword("bindu@cap.com","bindu@bu1");

			assertTrue("bindu@cap.com".equals(actual) || "bindu@bu1".equals(actual));
			
		
		
		}
		 
		@Test
		public void testfindByAddress(){
		
			
			UserService1 repository=new UserService1();

		assertEquals("Bangalore",repository.findByAddress("Bangalore"));
			
		}
		
		
		
		
	}

