package com.example.demo;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserService1 {

	@Autowired
	private UserRepository repo;
	
	
	
	public User create(String name, String password, String phone, String email, String address) {
		return repo.save(new User(name,password,phone,email,address));
		
	}
	
	public String findByPhone(String phone) {
		User u=new User("yashu","Tharun@2","9035117623","yashaswini.k@cap.com","Bangalore");
	System.out.println(phone);
		return u.getPhone();
	}
	
	
	public String findByName(String name) {
		User x=new User("yashu","Tharun@2","9035117623","yashaswini.k@cap.com","Bangalore");
	System.out.println(name);
	
		return x.getName();
	
	}
	public String findByEmail(String email) {
		User y=new User("Bindu","bindu@bu1","9964139248","bindu@cap.com","Bangalore");
		System.out.println(email);
	return y.getEmail();
}
	
	
	public String findByEmailAndPassword(String email, String password) {
		User y=new User("Bindu","bindu@bu1","9964139248","bindu@cap.com","Bangalore");
		
	return y.getEmail();
		
		
		
	}
	public String findByNameAndPassword(String name, String password) {
		User y=new User("Bindu","bindu@bu1","9964139248","bindu@cap.com","Bangalore");
		
	return y.getPassword();
		
		
		
	}
	public String findByAddress(String Address) {
		User u=new User("Bindu","bindu@bu1","9964139248","bindu@cap.com","Bangalore");
		System.out.println(u);
		return u.getAddress();
		
	}
	
}

