package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.User;
import com.example.demo.service.UserService;


@SessionAttributes("sessional")
@RestController
public class SignInController {
	
	@Autowired
	private UserService service;


	@RequestMapping(value="/signin", method = RequestMethod.POST)
	public ModelAndView validate(Model model,  @ModelAttribute("name") String name, @ModelAttribute("password") String password ) {
//		if (user != null && user.getName() != null & user.getPassword() != null) {
//			if (user.getName().equals("chandra") && user.getPassword().equals("chandra123")) {
//				model.addAttribute("msg", user.getName());
//				return "success";
//			} else {
//				model.addAttribute("error", "Invalid Details");
//				return "signin";
//			}
//		} else {
//			model.addAttribute("error", "Please enter Details");
//			return "signin";
//		}

		if(service.findByNameAndPassword(name, password) != null) {
			ModelAndView mav = new ModelAndView(); 
			//mav.addObject("users", user);
			model.addAttribute("sessional", name);
		
			mav.setViewName("index");
			return mav;
		}
		else {
			ModelAndView mav1 = new ModelAndView("signin");
			model.addAttribute("signinerror", "Invalid Login Credentials");
			return mav1;
		}
		
	}
}
